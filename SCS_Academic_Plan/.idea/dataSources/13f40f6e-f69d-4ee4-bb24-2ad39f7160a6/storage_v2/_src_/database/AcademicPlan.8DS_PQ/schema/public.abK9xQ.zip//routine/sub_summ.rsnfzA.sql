CREATE FUNCTION sub_summ (keyf integer) RETURNS TABLE(summ smallint)
	LANGUAGE plpgsql
AS $$
  
BEGIN
	SELECT SUM(exams_s) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(setoff_s) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(lect_s) + SUM(lab_s) + SUM(pract_s) + SUM(ksr_s) + SUM(bsr_S) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(lect_s) + SUM(lab_s) + SUM(pract_s) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(lect_s) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(lab_s) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(pract_s) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(ksr_s) + SUM(bsr_S) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(ksr_s) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
	SELECT SUM(bsr_s) INTO summ FROM subjects WHERE key_parts_fk = keyf;
	RETURN NEXT;
END
$$
