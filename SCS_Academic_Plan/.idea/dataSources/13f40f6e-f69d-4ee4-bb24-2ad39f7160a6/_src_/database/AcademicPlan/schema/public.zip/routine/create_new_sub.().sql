CREATE FUNCTION create_new_sub () RETURNS void
	LANGUAGE plpgsql
AS $$
BEGIN
EXECUTE format('
DROP TABLE IF EXISTS get_subjects;
   CREATE TABLE get_subjects AS
select
    key_subject
  , name_s
  , key_department_fk
  , exams_s
  , setoff_s
  , lect_s + lab_s + pract_s + ksr_s + bsr_s as sum_all
  , lect_s + lab_s + pract_s as sum_llp
  , lect_s
  , lab_s
  , pract_s
  , ksr_s + bsr_s as sum_kb
  , ksr_s
  , bsr_s
  
  , sum(case when course_num_sa = 1 then hour_lec_sa end) as hour_lec_sa_1
  , sum(case when course_num_sa = 1 then hour_lab_sa end) as hour_lab_sa_1
  , sum(case when course_num_sa = 1 then hour_prac_sa end) as hour_prac_sa_1 
  , sum(case when course_num_sa = 1 then hour_self_sa end) as hour_self_sa_1
  , sum(case when course_num_sa = 1 then hour_exam_sa end) as hour_exam_sa_1

  , sum(case when course_num_sa = 2 then hour_lec_sa end) as hour_lec_sa_2
  , sum(case when course_num_sa = 2 then hour_lab_sa end) as hour_lab_sa_2
  , sum(case when course_num_sa = 2 then hour_prac_sa end) as hour_prac_sa_2 
  , sum(case when course_num_sa = 2 then hour_self_sa end) as hour_self_sa_2
  , sum(case when course_num_sa = 2 then hour_exam_sa end) as hour_exam_sa_2

  , sum(case when course_num_sa = 3 then hour_lec_sa end) as hour_lec_sa_3
  , sum(case when course_num_sa = 3 then hour_lab_sa end) as hour_lab_sa_3
  , sum(case when course_num_sa = 3 then hour_prac_sa end) as hour_prac_sa_3 
  , sum(case when course_num_sa = 3 then hour_self_sa end) as hour_self_sa_3
  , sum(case when course_num_sa = 3 then hour_exam_sa end) as hour_exam_sa_3

  , sum(case when course_num_sa = 4 then hour_lec_sa end) as hour_lec_sa_4
  , sum(case when course_num_sa = 4 then hour_lab_sa end) as hour_lab_sa_4
  , sum(case when course_num_sa = 4 then hour_prac_sa end) as hour_prac_sa_4
  , sum(case when course_num_sa = 4 then hour_self_sa end) as hour_self_sa_4
  , sum(case when course_num_sa = 4 then hour_exam_sa end) as hour_exam_sa_4
from
  subjects s
  inner join subject_assignment a
    on s.key_subject_pk = a.key_subject_fk
  where s.key_cycle_fk = 1
group by
  key_subject_pk
order by key_subject_pk;');
END
$$
